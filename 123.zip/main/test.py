class qwe:
    _z = 1
    def __init__(self, a, b):
        self.gg = a
        self.hh = b


    
    
def main():
    '''
    a = 3
    b = 3
    c = [[1]*3 for _ in range(4)]
    print(c)
    for i in range(3):
        for j in range(3):
            print(c[i][j])
    '''
    a = [1,2,3]
    del a[1]
    print(a)
    return  

if __name__ == '__main__':
    a = main()
